/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aaa;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 *
 * @author Omkar
 */
public class gameplay extends JFrame{
    
    JButton b1=new JButton();
    JButton b2=new JButton();
    JButton b3=new JButton();
    JButton b4=new JButton();
    JButton b5=new JButton();
    JButton b6=new JButton();
    JButton b7=new JButton();
    JButton b8=new JButton();
    JButton b9=new JButton();
    
     JLabel l1=new JLabel();
    JLabel l2=new JLabel();
    int c=0,c1=2;
    String player1,player2;
    
    int[][] p=new int[3][3];
    
   
       
    public gameplay(String a,String b)
    {
        super("TIC-TAC-TOE");
        this.player1=a;
        this.player2=b;
//        super("TIC-TAC-TOE");
        setLayout(null);
      
        add(b1);
        add(b2);
        add(b3);
        add(b4);
        add(b5);
        add(b6);
        add(b7);
        add(b8);
        add(b9);
        
       
        
        b1.setBounds(100, 100, 100, 100);
        b2.setBounds(200, 100, 100, 100);
        b3.setBounds(300, 100, 100, 100);
        b4.setBounds(100, 200, 100, 100);
        b5.setBounds(200, 200, 100, 100);
        b6.setBounds(300, 200, 100, 100);
        b7.setBounds(100, 300, 100, 100);
        b8.setBounds(200, 300, 100, 100);
        b9.setBounds(300, 300, 100, 100);
        
         for(int i=0;i<=2;i++)
    {
        for(int j=0;j<=2;j++)
        {
            p[i][j]=c1;
            c1++;
        }
            
    }
    
        
        
        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(c%2==0)
                {
                    b1.setText("X");
                    p[0][0]=1;
                }
                else
                {
                    b1.setText("O");
                    p[0][0]=0;
                }
                c++;
                win();
                b1.setEnabled(false);
                
            }
        });
        b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(c%2==0)
                {
                    b2.setText("X");
                    p[0][1]=1;
                }
                else
                {
                    b2.setText("O");
                    p[0][1]=0;
                }
                c++; 
                win();
                b2.setEnabled(false);
            }
        });
        b3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(c%2==0)
                {
                    b3.setText("X");
                    p[0][2]=1;
                }
                else
                {
                    b3.setText("O");
                    p[0][2]=0;
                }
                c++;
                win();
         
                b3.setEnabled(false);
                
            }
        });
        b4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(c%2==0)
                {
                    b4.setText("X");
                    p[1][0]=1;
                }
                else
                {
                    b4.setText("O");
                    p[1][0]=0;
                }
                c++;
                win();
                b4.setEnabled(false);
            }
        });
        b5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(c%2==0)
                {
                    b5.setText("X");
                    p[1][1]=1;
                }
                else
                {
                    b5.setText("O");
                    p[1][1]=0;
                }
                c++;
                win();
                b5.setEnabled(false);
            }
        });
        b6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(c%2==0)
                {
                    b6.setText("X");
                    p[1][2]=1;
                }
                else
                {
                    b6.setText("O");
                    p[1][2]=0;
                }
                c++;
                win();
                b6.setEnabled(false); 
            }
        });
        b7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(c%2==0)
                {
                    b7.setText("X");
                    p[2][0]=1;
                }
                else
                {
                    b7.setText("O");
                    p[2][0]=0;
                }
                c++;
                win();
                b7.setEnabled(false);
            }
        });
        b8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(c%2==0)
                {
                    b8.setText("X");
                    p[2][1]=1;
                }
                else
                {
                    b8.setText("O");
                    p[2][1]=0;
                }
                c++;
                win();
                b8.setEnabled(false);
            }
        });
        b9.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(c%2==0)
                {
                    b9.setText("X");
                    p[2][2]=1;
                }
                else
                {
                    b9.setText("O");
                    p[2][2]=0;
                }
                c++;
                win();
                b9.setEnabled(false);
            }
        });

         
       
        
        setSize(500, 500);
        setVisible(true);
        
    }
    
    
    
    void win()
    {
        if((p[0][0]==p[0][1] && p[0][1]==p[0][2] && p[0][0]==p[0][2])||
                (p[1][0]==p[1][1] && p[1][1]==p[1][2] && p[1][0]==p[1][2])||
                (p[2][0]==p[2][1] && p[2][1]==p[2][2] && p[2][0]==p[2][2]))
        {
            if(c%2==0)
            {
            JOptionPane.showMessageDialog(gameplay.this,player2 +" WINNEDDDD");
            System.out.println("qwertyuiopasdfghjk");
            }
            else{
                JOptionPane.showMessageDialog(gameplay.this,player1 +" WINNEDDDD");
            System.out.println("qwertyuiopasdfghjk");
            }
        }
        else if((p[0][0]==p[1][0] && p[1][0]==p[2][0] && p[0][0]==p[2][0])||
                (p[0][1]==p[1][1] && p[1][1]==p[2][1] && p[0][1]==p[2][1])||
                (p[0][2]==p[1][2] && p[1][2]==p[2][2] && p[0][2]==p[2][2]))
        {
             if(c%2==0)
            {
            JOptionPane.showMessageDialog(gameplay.this,player2 +" WINNEDDDD");
            System.out.println("qwertyuiopasdfghjk");
            }
            else{
                JOptionPane.showMessageDialog(gameplay.this,player1 +" WINNEDDDD");
            System.out.println("qwertyuiopasdfghjk");
            }
        }
        else if ((p[0][0]==p[1][1] && p[1][1]==p[2][2] && p[0][0]==p[2][2])||
                (p[0][2]==p[1][1] && p[1][1]==p[2][0] && p[0][2]==p[2][0])
               )
        {
             if(c%2==0)
            {
            JOptionPane.showMessageDialog(gameplay.this,player2 +" WINNEDDDD");
            System.out.println("qwertyuiopasdfghjk");
            }
            else{
                JOptionPane.showMessageDialog(gameplay.this,player1 +" WINNEDDDD");
            System.out.println("qwertyuiopasdfghjk");
            }
        }
        else if(c==9)
        {
                        JOptionPane.showMessageDialog(gameplay.this, "Draw");

            
        }
        
    }
    
    
    
}
