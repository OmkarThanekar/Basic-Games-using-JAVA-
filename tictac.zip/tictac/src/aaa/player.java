/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aaa;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author Omkar
 */
public class player extends JFrame {
    JTextField t1=new JTextField(10);
    JTextField t2=new JTextField(10);
    
    JLabel l1=new JLabel("PLAYER 1-->");
    JLabel l2=new JLabel("PLAYER 2-->");
    
    JButton b=new JButton("Submit");
    
    public player()
    {
        super("PLAYER DETAILS");
        setLayout(null);
        add(l1);
        add(l2);
        add(t1);
        add(t2);
        add(b);
        
        l1.setBounds(100,100,100,50);
        l2.setBounds(100,200,100,50);
        
        t1.setBounds(200,100,100,50);
        t2.setBounds(200,200,100,50);
        
        b.setBounds(150,300,80,70);
        
        setSize(500,500);
        setVisible(true);
        
        b.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String p1=t1.getText().toString();
                String p2=t2.getText().toString();
//                System.out.println(p1+p2);
                new gameplay(p1,p2);
                dispose();
                
            }
        });

        
    }
    
    public static void main(String[] args) {
      player p=new player();
        
    }

    
}
