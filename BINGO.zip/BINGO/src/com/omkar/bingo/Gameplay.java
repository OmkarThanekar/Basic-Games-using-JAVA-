/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.omkar.bingo;

/**
 *
 * @author Omkar
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import jdk.nashorn.internal.ir.BreakNode;

/**
 *
 * @author Omkar
 */
public class Gameplay extends JFrame{
    
    
   
    JButton b1=new JButton();
    JButton b2=new JButton();
    JButton b3=new JButton();
    JButton b4=new JButton();
    JButton b5=new JButton();
    JButton b6=new JButton();
    JButton b7=new JButton();
    JButton b8=new JButton();
    JButton b9=new JButton();
    JButton b10=new JButton();
    JButton b11=new JButton();
    JButton b12=new JButton();
    JButton b13=new JButton();
    JButton b14=new JButton();
    JButton b15=new JButton();
    JButton b16=new JButton();
    JButton b17=new JButton();
    JButton b18=new JButton();
    JButton b19=new JButton();
    JButton b20=new JButton();
    JButton b21=new JButton();
    JButton b22=new JButton();
    JButton b23=new JButton();
    JButton b24=new JButton();
    JButton b25=new JButton();
    JButton B=new JButton();
    JButton i=new JButton();
    JButton n=new JButton();
    JButton g=new JButton();
    JButton o=new JButton();
    JButton Enum=new JButton("Fill Boxes");
    JButton Play=new JButton("Play again");
    
    
    int[][] p=new int[5][5];
    int c=2,x=50;
    int count1=0,count2=0,count3=0,count4=0,count5=0,count6=0,count7=0,count8=0,count9=0,count10=0,count11=0,count12=0;
    
   public Gameplay()
    {
        super("B I N G O");
        setLayout(null);
       
      
        add(b1);
        add(b2);
        add(b3);
        add(b4);
        add(b5);
        add(b6);
        add(b7);
        add(b8);
        add(b9);
        add(b10);
        add(b11);
        add(b12);
        add(b13);
        add(b14);
        add(b15);
        add(b16);
        add(b17);
        add(b18);
        add(b19);
        add(b20);
        add(b21);
        add(b22);
        add(b23);
        add(b24);
        add(b25);
        add(B);
        add(i);
        add(n);
        add(g);
        add(o);
        add(Enum);
        add(Play);
     
        b1.setBounds(100, 100,x, x);
        b2.setBounds(200, 100, x, x);
        b3.setBounds(300, 100, x, x);
        b4.setBounds(400, 100, x, x);
        b5.setBounds(500, 100, x, x);
        b6.setBounds(100, 200, x, x);
        b7.setBounds(200, 200,x , x);
        b8.setBounds(300, 200, x, x);
        b9.setBounds(400, 200, x, x);
        b10.setBounds(500, 200, x, x);
        b11.setBounds(100, 300, x, x);
        b12.setBounds(200, 300, x, x);
        b13.setBounds(300, 300, x, x);
        b14.setBounds(400, 300, x, x);
        b15.setBounds(500, 300, x, x);
        b16.setBounds(100, 400, x, x);
        b17.setBounds(200, 400, x, x);
        b18.setBounds(300, 400, x, x);
        b19.setBounds(400, 400, x, x);
        b20.setBounds(500, 400, x, x);
        b21.setBounds(100, 500, x, x);
        b22.setBounds(200, 500, x,x);
        b23.setBounds(300, 500, x, x);
        b24.setBounds(400, 500, x,x);
        b25.setBounds(500, 500, x, x);
        Enum.setBounds(500, 30, 200, 50);
        Play.setBounds(700, 30, 200, 50);
        
        
        B.setBounds(800, 100, x, x);
        B.setText("B");
        i.setBounds(800, 200, x, x);
        i.setText("I");
        n.setBounds(800, 300, x, x);
        n.setText("N");
        g.setBounds(800, 400, x, x);
        g.setText("G");
        o.setBounds(800, 500, x, x);
        o.setText("O");
        
 for(int i=0;i<=4;i++)
    {
        for(int j=0;j<=4;j++)
        {
            p[i][j]=c;
            c++;
        }
            
    }
 Enum.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               enterNum();
               Enum.setEnabled(false);
               game();
            }
        });
 Play.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
            dispose();
            new Gameplay();
            }
        });
        
         setSize(947 , 630);
        setVisible(true);
        
    }
   
   void game()
   {
         b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                p[0][0]=1;
                b1.setEnabled(false);
                bingo();
                
            }
        });
        b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               p[0][1]=1;
               b2.setEnabled(false);
               bingo();
            }
        });
        b3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                p[0][2]=1;
                b3.setEnabled(false);
                bingo();
            }
        });
        b4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               p[0][3]=1;
                b4.setEnabled(false);
                bingo();
            }
        });
        b5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                p[0][4]=1;
                b5.setEnabled(false);
                bingo();
            }
        });
        b6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                p[1][0]=1;
                b6.setEnabled(false);
                bingo(); 
            }
        });
        b7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                p[1][1]=1;
                b7.setEnabled(false);
                bingo();
            }
        });
        b8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                p[1][2]=1;
                b8.setEnabled(false);
                bingo();
            }
        });
        b9.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                p[1][3]=1;
                b9.setEnabled(false);
                bingo();
            }
        });
         b10.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                p[1][4]=1;
                b10.setEnabled(false);
                bingo();
                }
            });
            b11.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                p[2][0]=1;
                b11.setEnabled(false);
                bingo();
                }
            });
            b12.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                p[2][1]=1;
                b12.setEnabled(false);
                bingo();
                }
            });
            b13.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                p[2][2]=1;
                b13.setEnabled(false);
                bingo();}
            });
            b14.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                p[2][3]=1;
                b14.setEnabled(false);
                bingo();}
            });
            b15.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                p[2][4]=1;
                b15.setEnabled(false);
                bingo();}
            });
            b16.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                p[3][0]=1;
                b16.setEnabled(false);
                bingo();}
            });
            b17.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                p[3][1]=1;
                b17.setEnabled(false);
                bingo();}
            });
            b18.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                p[3][2]=1;
                b18.setEnabled(false);
                bingo();}
            });
            b19.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                p[3][3]=1;
                b19.setEnabled(false);
                bingo();}
            });
            b20.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                p[3][4]=1;
                b20.setEnabled(false);
                bingo();}
            });
            b21.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                p[4][0]=1;
                b21.setEnabled(false);
                bingo();}
            });
            b22.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                p[4][1]=1;
                b22.setEnabled(false);
                bingo();}
            });
            b23.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                p[4][2]=1;
                b23.setEnabled(false);
                bingo();}
            });
            b24.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                p[4][3]=1;
                b24.setEnabled(false);
                bingo();}
            });
            b25.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                p[4][4]=1;
                b25.setEnabled(false);
                bingo();}
            });

   }
    
    
    void bingo()
    {
        
        if((p[0][0]==p[0][1] && p[0][1]==p[0][2] && p[0][2]==p[0][3] && p[0][3]==p[0][4] && p[0][0]==p[0][4]) && count1==0 )  //Rows
        {
            
            disableb();
            System.out.println("Row1");
            count1++;   
        }
        if ((p[1][0]==p[1][1] && p[1][1]==p[1][2] && p[1][2]==p[1][3] && p[1][3]==p[1][4] && p[1][0]==p[1][4]) && count2==0) {
            disableb();
            System.out.println("Row 2");
            count2++;
        }
        if((p[2][0]==p[2][1] && p[2][1]==p[2][2] && p[2][2]==p[2][3] && p[2][3]==p[2][4] && p[2][0]==p[2][4]) && count3==0)
        {
            disableb();
            System.out.println("Row 3");
            count3++;
        }
        if((p[3][0]==p[3][1] && p[3][1]==p[3][2] && p[3][2]==p[3][3] && p[3][3]==p[3][4] && p[3][0]==p[3][4]) && count4==0)
        {
            disableb();
            System.out.println("Row 4");
            count4++;
        }
        if((p[4][0]==p[4][1] && p[4][1]==p[4][2] && p[4][2]==p[4][3] && p[4][3]==p[4][4] && p[4][0]==p[4][4]) && count5==0)
        {
          disableb();
            System.out.println("Row 5");   
            count5++;
        }
        if((p[0][0]==p[1][0] && p[1][0]==p[2][0] && p[2][0]==p[3][0] && p[3][0]==p[4][0] && p[0][0]==p[4][0]) && count6==0)   //columns
        {
            disableb();
            System.out.println("col 1");
            count6++;
        }
        if((p[0][1]==p[1][1] && p[1][1]==p[2][1] && p[2][1]==p[3][1] && p[3][1]==p[4][1] && p[0][1]==p[4][1]) && count7==0)
        {
            disableb();
            System.out.println("col 2");
            count7++;
        }
        if((p[0][2]==p[1][2] && p[1][2]==p[2][2] && p[2][2]==p[3][2] && p[3][2]==p[4][2] && p[0][2]==p[4][2]) && count8==0)
        {
            disableb();
            System.out.println("col 3");
            count8++;
        }
        if((p[0][3]==p[1][3] && p[1][3]==p[2][3] && p[2][3]==p[3][3] && p[3][3]==p[4][3] && p[0][3]==p[4][3]) && count9==0)
        {
            disableb();
            System.out.println("col 4");
            count9++;
        }
        if((p[0][4]==p[1][4] && p[1][4]==p[2][4] && p[2][4]==p[3][4] && p[3][4]==p[4][4] && p[0][4]==p[4][4]) && count10==0)
        {
           disableb();
            System.out.println("col 5");
            count10++;
        }
        if((p[0][0]==p[1][1] && p[1][1]==p[2][2] && p[2][2]==p[3][3] && p[3][3]==p[4][4] && p[0][0]==p[4][4]) && count11==0)      //diagonals
        {
            disableb();
            System.out.println("Diagonal 1");
            count11++;
        }
        if((p[0][4]==p[1][3] && p[1][3]==p[2][2] && p[2][2]==p[3][1] && p[3][1]==p[4][0] && p[0][4]==p[4][0]) && count12==0)
        {
            disableb();
            System.out.println("Diagonal 2");
            count12++;
        }
    }
    void disableb()
    {
       
        if(B.isEnabled())
        {
            B.setEnabled(false);
        }
        else if(i.isEnabled())
        {
            i.setEnabled(false);
        }
        else if(n.isEnabled())
        {
            n.setEnabled(false);
        }
        else if(g.isEnabled())
        {
            g.setEnabled(false);
        }
        else if(o.isEnabled())
        {
            o.setEnabled(false);
            win();
        }
    }
    
    void win()
    {
        JOptionPane.showMessageDialog(Gameplay.this,"B*I*N*G*O");
    }
    
    void enterNum()
    {
        //To enter random numbers in boxes 
        int[] arr=new int[25];
        int[] random=new int[25];
        int c=1;
        int max=25;
        int min=1;
        int i;
        int range=max-min+1;
        for(i=0;i<25;i++)
        {
            arr[i]=100;
        }
        i=0;
        
        while(true)
        {
           int rand=(int) ((Math.random()*range)+min);
//            System.out.println(arr.equals(rand));
            int status=Arrays.binarySearch(arr, rand);
            if(status>=0)
            {
                continue;
            }
            else{
                System.out.println(rand);
                random[i]=rand;
                arr[i]=rand;
                Arrays.sort(arr);
                i++;
                c++;
                if(c>25)
                    break;
            }
        }
      b1.setText(Integer.toString(random[0]));
      b2.setText(Integer.toString(random[1]));
      b3.setText(Integer.toString(random[2]));
      b4.setText(Integer.toString(random[3]));
      b5.setText(Integer.toString(random[4]));
      b6.setText(Integer.toString(random[5]));
      b7.setText(Integer.toString(random[6]));
      b8.setText(Integer.toString(random[7]));
      b9.setText(Integer.toString(random[8]));
      b10.setText(Integer.toString(random[9]));
      b11.setText(Integer.toString(random[10]));
      b12.setText(Integer.toString(random[11]));
      b13.setText(Integer.toString(random[12]));
      b14.setText(Integer.toString(random[13]));
      b15.setText(Integer.toString(random[14]));
      b16.setText(Integer.toString(random[15]));
      b17.setText(Integer.toString(random[16]));
      b18.setText(Integer.toString(random[17]));
      b19.setText(Integer.toString(random[18]));
      b20.setText(Integer.toString(random[19]));
      b21.setText(Integer.toString(random[20]));
      b22.setText(Integer.toString(random[21]));
      b23.setText(Integer.toString(random[22]));
      b24.setText(Integer.toString(random[23]));
      b25.setText(Integer.toString(random[24]));
    }
    
    public static void main(String[] args) {
        Gameplay g=new Gameplay();
    }
}

    
    
    